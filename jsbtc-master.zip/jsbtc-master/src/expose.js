if (typeof __dirname === 'undefined') {
  let __dirname = '';
  module.exports = {__dirname};
} else {
  module.exports = {__dirname};
}